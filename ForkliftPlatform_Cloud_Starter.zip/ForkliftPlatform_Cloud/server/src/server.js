import 'dotenv/config';
import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import argon2 from 'argon2';
import { Pool } from 'pg';
import { OAuth2Client } from 'google-auth-library';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';

const required = ['DATABASE_URL', 'SESSION_SECRET', 'FOUNDER_BOOTSTRAP_TOKEN'];
for (const key of required) if (!process.env[key]) throw new Error(`Missing environment variable: ${key}`);
if (Buffer.byteLength(process.env.SESSION_SECRET) < 32) throw new Error('SESSION_SECRET must be at least 32 bytes');

const app = Fastify({ logger: true, trustProxy: true, bodyLimit: 1024 * 1024 });
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const cookieName = process.env.SESSION_COOKIE_NAME || 'fp_session';
const google = process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
  ? new OAuth2Client(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_CALLBACK_URL)
  : null;

await app.register(helmet, { contentSecurityPolicy: false });
await app.register(cookie, { secret: process.env.SESSION_SECRET, hook: 'onRequest' });
await app.register(cors, { origin: (process.env.FRONTEND_ORIGIN || '').split(',').filter(Boolean), credentials: true });
await app.register(rateLimit, { max: 120, timeWindow: '1 minute' });

const sha = value => createHash('sha256').update(value).digest('hex');
const safeEq = (a, b) => { const x = Buffer.from(String(a)); const y = Buffer.from(String(b)); return x.length === y.length && timingSafeEqual(x, y); };
const isProd = process.env.NODE_ENV === 'production';
const cookieOpts = { httpOnly: true, secure: isProd, sameSite: isProd ? 'none' : 'lax', path: '/' };

async function getSession(req) {
  const raw = req.cookies?.[cookieName];
  if (!raw) return null;
  const { rows } = await pool.query(`SELECT s.token_hash, s.expires_at, u.id, u.username, u.display_name, u.email, u.role, u.status
    FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now()`, [sha(raw)]);
  const row = rows[0];
  if (!row || row.status !== 'ACTIVE') return null;
  return { ...row, token_hash: undefined };
}
async function auth(req, reply) {
  req.user = await getSession(req);
  if (!req.user) return reply.code(401).send({ error: 'AUTH_REQUIRED' });
}
async function admin(req, reply) {
  await auth(req, reply); if (reply.sent) return;
  if (!['FOUNDER', 'ADMIN'].includes(req.user.role)) return reply.code(403).send({ error: 'FORBIDDEN' });
}
async function founder(req, reply) {
  await auth(req, reply); if (reply.sent) return;
  if (req.user.role !== 'FOUNDER') return reply.code(403).send({ error: 'FOUNDER_ONLY' });
}
async function hasPermission(user, permission) {
  if (user.role === 'FOUNDER') return true;
  const { rows } = await pool.query('SELECT allowed FROM role_permissions WHERE role=$1 AND permission=$2', [user.role, permission]);
  return rows[0]?.allowed === true;
}
function requirePermission(permission) {
  return async (req, reply) => { await auth(req, reply); if (reply.sent) return; if (!(await hasPermission(req.user, permission))) return reply.code(403).send({ error: 'PERMISSION_DENIED', permission }); };
}
async function audit(actorId, action, targetId = null, details = {}) {
  await pool.query('INSERT INTO audit_logs(actor_id,target_user_id,action,details) VALUES($1,$2,$3,$4)', [actorId, targetId, action, JSON.stringify(details)]);
}
async function issueSession(reply, user, remember = false) {
  const raw = randomBytes(32).toString('base64url');
  const hours = remember ? 30 * 24 : 8;
  await pool.query("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+($3::int * interval '1 hour'))", [sha(raw), user.id, hours]);
  reply.setCookie(cookieName, raw, { ...cookieOpts, maxAge: hours * 3600 });
}
async function checkOrigin(req, reply) {
  const allowed = (process.env.FRONTEND_ORIGIN || '').split(',').filter(Boolean);
  const origin = req.headers.origin;
  if (origin && allowed.length && !allowed.includes(origin)) return reply.code(403).send({ error: 'BAD_ORIGIN' });
}
app.addHook('preHandler', async (req, reply) => {
  if (['POST','PUT','PATCH','DELETE'].includes(req.method)) await checkOrigin(req, reply);
});

app.get('/health', async () => ({ ok: true, service: 'forklift-platform-api', time: new Date().toISOString() }));
app.post('/api/auth/bootstrap-founder', async (req, reply) => {
  const body = z.object({ token: z.string().min(24), username: z.string().regex(/^[a-z0-9._-]{3,24}$/i), displayName: z.string().min(2).max(80), email: z.string().email().optional(), password: z.string().min(12) }).safeParse(req.body);
  if (!body.success) return reply.code(400).send({ error: 'INVALID_INPUT', details: body.error.flatten() });
  if (!safeEq(body.data.token, process.env.FOUNDER_BOOTSTRAP_TOKEN)) return reply.code(403).send({ error: 'INVALID_BOOTSTRAP_TOKEN' });
  const count = await pool.query("SELECT count(*)::int AS n FROM users WHERE role='FOUNDER'");
  if (count.rows[0].n) return reply.code(409).send({ error: 'FOUNDER_ALREADY_EXISTS' });
  const hash = await argon2.hash(body.data.password, { type: argon2.argon2id });
  const { rows } = await pool.query(`INSERT INTO users(username,display_name,email,password_hash,role)
    VALUES(lower($1),$2,lower($3),$4,'FOUNDER') RETURNING id,username,display_name,email,role,status`, [body.data.username, body.data.displayName, body.data.email || null, hash]);
  await audit(rows[0].id, 'FOUNDER_BOOTSTRAPPED', rows[0].id);
  await issueSession(reply, rows[0]);
  return reply.code(201).send({ user: rows[0] });
});
app.post('/api/auth/login', async (req, reply) => {
  const b = z.object({ username: z.string().min(3), password: z.string().min(1), remember: z.boolean().optional() }).safeParse(req.body);
  if (!b.success) return reply.code(400).send({ error: 'INVALID_INPUT' });
  const { rows } = await pool.query('SELECT * FROM users WHERE lower(username)=lower($1)', [b.data.username]);
  const u = rows[0];
  if (!u || u.status !== 'ACTIVE' || !u.password_hash || !(await argon2.verify(u.password_hash, b.data.password))) return reply.code(401).send({ error: 'INVALID_CREDENTIALS_OR_SUSPENDED' });
  await issueSession(reply, u, !!b.data.remember);
  await pool.query('UPDATE users SET last_login_at=now() WHERE id=$1', [u.id]);
  await audit(u.id, 'LOGIN');
  return { user: { id:u.id, username:u.username, displayName:u.display_name, email:u.email, role:u.role } };
});
app.post('/api/auth/logout', { preHandler: auth }, async (req, reply) => {
  const raw = req.cookies?.[cookieName]; if (raw) await pool.query('DELETE FROM sessions WHERE token_hash=$1', [sha(raw)]);
  reply.clearCookie(cookieName, { path: '/' }); return { ok: true };
});
app.get('/api/auth/me', { preHandler: auth }, async req => ({ user: { id:req.user.id, username:req.user.username, displayName:req.user.display_name, email:req.user.email, role:req.user.role } }));

app.get('/api/auth/google', async (req, reply) => {
  if (!google) return reply.code(503).send({ error: 'GOOGLE_OAUTH_NOT_CONFIGURED' });
  const purpose = req.query?.purpose === 'link' ? 'link' : 'login';
  if (purpose === 'link') { req.user = await getSession(req); if (!req.user) return reply.code(401).send({ error: 'AUTH_REQUIRED_TO_LINK' }); }
  const state = randomBytes(24).toString('base64url');
  const nonce = randomBytes(24).toString('base64url');
  reply.setCookie('fp_google_state', `${state}.${purpose}.${nonce}`, { ...cookieOpts, maxAge: 600 });
  const url = google.generateAuthUrl({ access_type:'online', prompt:'select_account', scope:['openid','email','profile'], state, nonce });
  return reply.redirect(url);
});
app.get('/api/auth/google/callback', async (req, reply) => {
  if (!google) return reply.code(503).send({ error: 'GOOGLE_OAUTH_NOT_CONFIGURED' });
  const saved = req.cookies?.fp_google_state || ''; const [state, purpose, nonce] = saved.split('.');
  reply.clearCookie('fp_google_state', { path:'/' });
  if (!state || !safeEq(state, String(req.query.state || ''))) return reply.code(400).send({ error:'INVALID_OAUTH_STATE' });
  try {
    const { tokens } = await google.getToken(String(req.query.code || ''));
    const ticket = await google.verifyIdToken({ idToken: tokens.id_token, audience: process.env.GOOGLE_CLIENT_ID });
    const p = ticket.getPayload();
    if (!p?.sub || p.email_verified !== true || !p.nonce || !safeEq(p.nonce, nonce || '')) return reply.code(403).send({ error:'GOOGLE_IDENTITY_CHECK_FAILED' });
    if (purpose === 'link') {
      const user = await getSession(req); if (!user) return reply.code(401).send({ error:'LOGIN_AGAIN_TO_LINK' });
      await pool.query(`INSERT INTO oauth_accounts(user_id,provider,provider_subject,email) VALUES($1,'google',$2,$3)
        ON CONFLICT(user_id,provider) DO UPDATE SET provider_subject=EXCLUDED.provider_subject,email=EXCLUDED.email`, [user.id,p.sub,p.email || null]);
      await audit(user.id,'GOOGLE_ACCOUNT_LINKED',user.id,{email:p.email});
      return reply.redirect(`${(process.env.APP_ORIGIN || process.env.FRONTEND_ORIGIN || '').replace(/\/$/,'')}/admin-console.html?google=linked`);
    }
    const found = await pool.query(`SELECT u.* FROM oauth_accounts a JOIN users u ON u.id=a.user_id WHERE a.provider='google' AND a.provider_subject=$1`, [p.sub]);
    const u = found.rows[0];
    if (!u || u.status !== 'ACTIVE') return reply.code(403).send({ error:'GOOGLE_ACCOUNT_NOT_LINKED_OR_SUSPENDED' });
    await issueSession(reply,u); await audit(u.id,'GOOGLE_LOGIN');
    return reply.redirect(`${(process.env.APP_ORIGIN || process.env.FRONTEND_ORIGIN || '').replace(/\/$/,'')}/admin-console.html?google=login`);
  } catch (e) { req.log.error(e); return reply.code(400).send({ error:'GOOGLE_OAUTH_FAILED' }); }
});

app.get('/api/admin/users', { preHandler: admin }, async () => {
  const { rows } = await pool.query(`SELECT id,username,display_name,email,role,status,suspension_reason,suspended_at,created_at,last_login_at FROM users ORDER BY created_at DESC`);
  return { users: rows };
});
app.post('/api/admin/users', { preHandler: admin }, async (req, reply) => {
  const b = z.object({ username:z.string().regex(/^[a-z0-9._-]{3,24}$/i), displayName:z.string().min(2).max(80), email:z.string().email().optional(), role:z.enum(['ADMIN','ENGINEER','SUPERVISOR','USER','GUEST']).default('USER'), password:z.string().min(12) }).safeParse(req.body);
  if (!b.success) return reply.code(400).send({error:'INVALID_INPUT',details:b.error.flatten()});
  if (req.user.role !== 'FOUNDER' && b.data.role === 'ADMIN') return reply.code(403).send({error:'FOUNDER_REQUIRED_TO_CREATE_ADMIN'});
  const hash = await argon2.hash(b.data.password,{type:argon2.argon2id});
  try {
    const {rows}=await pool.query(`INSERT INTO users(username,display_name,email,password_hash,role) VALUES(lower($1),$2,lower($3),$4,$5) RETURNING id,username,display_name,email,role,status`,[b.data.username,b.data.displayName,b.data.email||null,hash,b.data.role]);
    await audit(req.user.id,'USER_CREATED',rows[0].id,{role:b.data.role}); return reply.code(201).send({user:rows[0]});
  } catch(e) { if(e.code==='23505') return reply.code(409).send({error:'USERNAME_OR_EMAIL_ALREADY_EXISTS'}); throw e; }
});
app.patch('/api/admin/users/:id', { preHandler: admin }, async (req, reply) => {
  const b=z.object({username:z.string().regex(/^[a-z0-9._-]{3,24}$/i).optional(),displayName:z.string().min(2).max(80).optional(),email:z.string().email().nullable().optional(),role:z.enum(['ADMIN','ENGINEER','SUPERVISOR','USER','GUEST']).optional(),password:z.string().min(12).optional()}).strict().safeParse(req.body);
  if(!b.success) return reply.code(400).send({error:'INVALID_INPUT',details:b.error.flatten()});
  const target=(await pool.query('SELECT * FROM users WHERE id=$1',[req.params.id])).rows[0];
  if(!target) return reply.code(404).send({error:'USER_NOT_FOUND'});
  if(target.role==='FOUNDER') return reply.code(403).send({error:'FOUNDER_ACCOUNT_PROTECTED'});
  if(req.user.role!=='FOUNDER' && (target.role==='ADMIN' || b.data.role==='ADMIN')) return reply.code(403).send({error:'FOUNDER_REQUIRED'});
  const d=b.data; const passwordHash=d.password?await argon2.hash(d.password,{type:argon2.argon2id}):target.password_hash;
  const {rows}=await pool.query(`UPDATE users SET username=COALESCE($2,username),display_name=COALESCE($3,display_name),email=CASE WHEN $4::boolean THEN lower($5) ELSE email END,role=COALESCE($6,role),password_hash=$7,updated_at=now() WHERE id=$1 RETURNING id,username,display_name,email,role,status`,[target.id,d.username||null,d.displayName||null,Object.hasOwn(d,'email'),d.email??null,d.role||null,passwordHash]);
  if(d.password) await pool.query('DELETE FROM sessions WHERE user_id=$1',[target.id]);
  await audit(req.user.id,'USER_UPDATED',target.id,{fields:Object.keys(d)}); return {user:rows[0]};
});
app.post('/api/admin/users/:id/suspend', { preHandler: admin }, async (req, reply) => {
  const b=z.object({reason:z.string().trim().min(5).max(500)}).safeParse(req.body); if(!b.success) return reply.code(400).send({error:'SUSPENSION_REASON_REQUIRED'});
  const target=(await pool.query('SELECT id,role,status FROM users WHERE id=$1',[req.params.id])).rows[0];
  if(!target) return reply.code(404).send({error:'USER_NOT_FOUND'});
  if(target.role==='FOUNDER') return reply.code(403).send({error:'FOUNDER_ACCOUNT_PROTECTED'});
  if(req.user.id===target.id) return reply.code(400).send({error:'CANNOT_SUSPEND_SELF'});
  if(req.user.role!=='FOUNDER' && target.role==='ADMIN') return reply.code(403).send({error:'FOUNDER_REQUIRED'});
  await pool.query(`UPDATE users SET status='SUSPENDED',suspension_reason=$2,suspended_at=now(),suspended_by=$3,updated_at=now() WHERE id=$1`,[target.id,b.data.reason,req.user.id]);
  await pool.query('DELETE FROM sessions WHERE user_id=$1',[target.id]); await audit(req.user.id,'USER_SUSPENDED',target.id,{reason:b.data.reason}); return {ok:true,status:'SUSPENDED'};
});
app.post('/api/admin/users/:id/restore', { preHandler: admin }, async (req, reply) => {
  const target=(await pool.query('SELECT id,role FROM users WHERE id=$1',[req.params.id])).rows[0];
  if(!target) return reply.code(404).send({error:'USER_NOT_FOUND'});
  if(target.role==='FOUNDER') return reply.code(403).send({error:'FOUNDER_ACCOUNT_PROTECTED'});
  if(req.user.role!=='FOUNDER' && target.role==='ADMIN') return reply.code(403).send({error:'FOUNDER_REQUIRED'});
  await pool.query(`UPDATE users SET status='ACTIVE',suspension_reason=NULL,suspended_at=NULL,suspended_by=NULL,updated_at=now() WHERE id=$1`,[target.id]);
  await audit(req.user.id,'USER_RESTORED',target.id); return {ok:true,status:'ACTIVE'};
});
app.get('/api/admin/permissions', { preHandler: auth }, async req => {
  const {rows}=await pool.query('SELECT permission,allowed FROM role_permissions WHERE role=$1 ORDER BY permission',[req.user.role]);
  const permissions=Object.fromEntries(rows.map(r=>[r.permission,r.allowed]));
  if(req.user.role==='FOUNDER') permissions['*']=true;
  return {role:req.user.role,permissions};
});
app.get('/api/admin/roles', { preHandler: founder }, async () => {
  const {rows}=await pool.query('SELECT role,permission,allowed FROM role_permissions ORDER BY role,permission');
  return {permissions:rows};
});
app.patch('/api/admin/roles/:role/permissions/:permission', { preHandler: founder }, async (req,reply) => {
  const role=z.enum(['ADMIN','ENGINEER','SUPERVISOR','USER','GUEST']).safeParse(req.params.role);
  const permission=z.string().regex(/^[a-z][a-z0-9_]{1,63}$/).safeParse(req.params.permission);
  const body=z.object({allowed:z.boolean()}).safeParse(req.body);
  if(!role.success||!permission.success||!body.success) return reply.code(400).send({error:'INVALID_INPUT'});
  await pool.query(`INSERT INTO role_permissions(role,permission,allowed,updated_by) VALUES($1,$2,$3,$4)
    ON CONFLICT(role,permission) DO UPDATE SET allowed=EXCLUDED.allowed,updated_by=EXCLUDED.updated_by,updated_at=now()`,[role.data,permission.data,body.data.allowed,req.user.id]);
  await audit(req.user.id,'ROLE_PERMISSION_CHANGED',null,{role:role.data,permission:permission.data,allowed:body.data.allowed});
  return {ok:true};
});
app.get('/api/admin/settings', { preHandler: founder }, async () => {
  const {rows}=await pool.query('SELECT setting_key,setting_value,updated_at FROM app_settings ORDER BY setting_key');
  return {settings:rows};
});
app.put('/api/admin/settings/:key', { preHandler: founder }, async (req,reply) => {
  const key=z.string().regex(/^[a-z][a-z0-9_.-]{1,79}$/).safeParse(req.params.key);
  const wrapped=z.object({value:z.unknown()}).safeParse(req.body);
  if(!key.success||!wrapped.success) return reply.code(400).send({error:'INVALID_INPUT'});
  await pool.query(`INSERT INTO app_settings(setting_key,setting_value,updated_by) VALUES($1,$2,$3)
    ON CONFLICT(setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_by=EXCLUDED.updated_by,updated_at=now()`,[key.data,JSON.stringify(wrapped.data.value),req.user.id]);
  await audit(req.user.id,'SITE_SETTING_UPDATED',null,{key:key.data}); return {ok:true};
});
app.get('/api/admin/stats', { preHandler: founder }, async () => {
  const [users,projects,templates,components]=await Promise.all([
    pool.query(`SELECT role,status,count(*)::int AS count FROM users GROUP BY role,status`),
    pool.query('SELECT count(*)::int AS count FROM simulator_projects'),
    pool.query('SELECT count(*)::int AS count FROM circuit_templates WHERE published=true'),
    pool.query('SELECT count(*)::int AS count FROM simulator_components WHERE active=true')
  ]);
  return {users:users.rows,projects:projects.rows[0].count,publishedTemplates:templates.rows[0].count,activeComponents:components.rows[0].count};
});

app.get('/api/admin/audit', { preHandler: founder }, async req => {
  const limit=Math.min(500,Math.max(1,Number(req.query.limit)||100));
  const {rows}=await pool.query(`SELECT a.id,a.action,a.details,a.created_at,u.username AS actor,t.username AS target FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id LEFT JOIN users t ON t.id=a.target_user_id ORDER BY a.id DESC LIMIT $1`,[limit]); return {logs:rows};
});

app.get('/api/simulator/catalog', { preHandler: auth }, async () => {
  const {rows}=await pool.query('SELECT id,category,label_ar,label_en,symbol_kind,terminal_labels,terminal_positions,metadata FROM simulator_components WHERE active=true ORDER BY category,label_en'); return {components:rows};
});
app.get('/api/simulator/templates', { preHandler: auth }, async req => {
  const category=req.query.category; const args=[]; let where='published=true';
  if(category){args.push(category);where+=' AND category=$1';}
  const {rows}=await pool.query(`SELECT id,slug,title_ar,title_en,category,difficulty,description,safety_notes FROM circuit_templates WHERE ${where} ORDER BY category,title_en`,args); return {templates:rows};
});
app.get('/api/simulator/templates/:slug', { preHandler: auth }, async (req,reply) => {
  const {rows}=await pool.query('SELECT * FROM circuit_templates WHERE slug=$1 AND published=true',[req.params.slug]); if(!rows[0]) return reply.code(404).send({error:'TEMPLATE_NOT_FOUND'}); return {template:rows[0]};
});
app.post('/api/admin/simulator/components', { preHandler: requirePermission('manage_simulator_catalog') }, async (req,reply) => {
  const b=z.object({id:z.string().regex(/^[A-Z][A-Z0-9_]{1,19}$/),category:z.string().min(2).max(40),labelAr:z.string().min(1).max(100),labelEn:z.string().min(1).max(100),symbolKind:z.string().min(2).max(60),terminalLabels:z.array(z.string().max(30)).max(32),terminalPositions:z.array(z.tuple([z.number(),z.number()])).max(32),metadata:z.record(z.any()).optional(),active:z.boolean().optional()}).safeParse(req.body);
  if(!b.success) return reply.code(400).send({error:'INVALID_INPUT',details:b.error.flatten()});
  const d=b.data;
  const {rows}=await pool.query(`INSERT INTO simulator_components(id,category,label_ar,label_en,symbol_kind,terminal_labels,terminal_positions,metadata,active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[d.id,d.category,d.labelAr,d.labelEn,d.symbolKind,JSON.stringify(d.terminalLabels),JSON.stringify(d.terminalPositions),JSON.stringify(d.metadata||{}),d.active!==false]);
  await audit(req.user.id,'SIMULATOR_COMPONENT_CREATED',null,{componentId:d.id}); return reply.code(201).send({component:rows[0]});
});
app.patch('/api/admin/simulator/components/:id', { preHandler: requirePermission('manage_simulator_catalog') }, async (req,reply) => {
  const b=z.object({category:z.string().min(2).max(40).optional(),labelAr:z.string().min(1).max(100).optional(),labelEn:z.string().min(1).max(100).optional(),symbolKind:z.string().min(2).max(60).optional(),terminalLabels:z.array(z.string().max(30)).max(32).optional(),terminalPositions:z.array(z.tuple([z.number(),z.number()])).max(32).optional(),metadata:z.record(z.any()).optional(),active:z.boolean().optional()}).strict().safeParse(req.body);
  if(!b.success) return reply.code(400).send({error:'INVALID_INPUT',details:b.error.flatten()});
  const old=(await pool.query('SELECT * FROM simulator_components WHERE id=$1',[req.params.id])).rows[0]; if(!old) return reply.code(404).send({error:'COMPONENT_NOT_FOUND'});
  const d=b.data; const {rows}=await pool.query(`UPDATE simulator_components SET category=$2,label_ar=$3,label_en=$4,symbol_kind=$5,terminal_labels=$6,terminal_positions=$7,metadata=$8,active=$9,updated_at=now() WHERE id=$1 RETURNING *`,[old.id,d.category??old.category,d.labelAr??old.label_ar,d.labelEn??old.label_en,d.symbolKind??old.symbol_kind,JSON.stringify(d.terminalLabels??old.terminal_labels),JSON.stringify(d.terminalPositions??old.terminal_positions),JSON.stringify(d.metadata??old.metadata),d.active??old.active]);
  await audit(req.user.id,'SIMULATOR_COMPONENT_UPDATED',null,{componentId:old.id,fields:Object.keys(d)}); return {component:rows[0]};
});
app.post('/api/admin/simulator/templates', { preHandler: requirePermission('manage_circuit_templates') }, async (req,reply) => {
  const b=z.object({slug:z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100),titleAr:z.string().min(2).max(160),titleEn:z.string().min(2).max(160),category:z.enum(['POWER','CONTROL','MIXED','MEASUREMENT']),difficulty:z.enum(['BEGINNER','INTERMEDIATE','ADVANCED']).default('BEGINNER'),description:z.string().max(2000).default(''),safetyNotes:z.array(z.string().max(500)).default([]),circuitData:z.record(z.any()),published:z.boolean().default(false)}).safeParse(req.body);
  if(!b.success) return reply.code(400).send({error:'INVALID_INPUT',details:b.error.flatten()}); const d=b.data;
  const {rows}=await pool.query(`INSERT INTO circuit_templates(slug,title_ar,title_en,category,difficulty,description,safety_notes,circuit_data,published) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[d.slug,d.titleAr,d.titleEn,d.category,d.difficulty,d.description,JSON.stringify(d.safetyNotes),JSON.stringify(d.circuitData),d.published]);
  await audit(req.user.id,'CIRCUIT_TEMPLATE_CREATED',null,{slug:d.slug}); return reply.code(201).send({template:rows[0]});
});
app.patch('/api/admin/simulator/templates/:slug', { preHandler: requirePermission('manage_circuit_templates') }, async (req,reply) => {
  const b=z.object({titleAr:z.string().min(2).max(160).optional(),titleEn:z.string().min(2).max(160).optional(),category:z.enum(['POWER','CONTROL','MIXED','MEASUREMENT']).optional(),difficulty:z.enum(['BEGINNER','INTERMEDIATE','ADVANCED']).optional(),description:z.string().max(2000).optional(),safetyNotes:z.array(z.string().max(500)).optional(),circuitData:z.record(z.any()).optional(),published:z.boolean().optional()}).strict().safeParse(req.body);
  if(!b.success) return reply.code(400).send({error:'INVALID_INPUT',details:b.error.flatten()}); const old=(await pool.query('SELECT * FROM circuit_templates WHERE slug=$1',[req.params.slug])).rows[0]; if(!old) return reply.code(404).send({error:'TEMPLATE_NOT_FOUND'}); const d=b.data;
  const {rows}=await pool.query(`UPDATE circuit_templates SET title_ar=$2,title_en=$3,category=$4,difficulty=$5,description=$6,safety_notes=$7,circuit_data=$8,published=$9,updated_at=now() WHERE slug=$1 RETURNING *`,[old.slug,d.titleAr??old.title_ar,d.titleEn??old.title_en,d.category??old.category,d.difficulty??old.difficulty,d.description??old.description,JSON.stringify(d.safetyNotes??old.safety_notes),JSON.stringify(d.circuitData??old.circuit_data),d.published??old.published]);
  await audit(req.user.id,'CIRCUIT_TEMPLATE_UPDATED',null,{slug:old.slug,fields:Object.keys(d)}); return {template:rows[0]};
});

app.get('/api/simulator/projects', { preHandler: auth }, async req => {
  const params=[]; let where='';
  if(req.user.role!=='FOUNDER'){params.push(req.user.id);where='WHERE owner_id=$1';}
  const {rows}=await pool.query(`SELECT id,owner_id,title,description,created_at,updated_at FROM simulator_projects ${where} ORDER BY updated_at DESC`,params); return {projects:rows};
});
app.post('/api/simulator/projects', { preHandler: auth }, async (req,reply) => {
  const b=z.object({title:z.string().min(1).max(120),description:z.string().max(1000).optional(),projectData:z.record(z.any())}).safeParse(req.body); if(!b.success) return reply.code(400).send({error:'INVALID_INPUT'});
  const client=await pool.connect();
  try { await client.query('BEGIN');
    const {rows}=await client.query('INSERT INTO simulator_projects(owner_id,title,description,project_data) VALUES($1,$2,$3,$4) RETURNING id,title,description,project_data,created_at,updated_at',[req.user.id,b.data.title,b.data.description||'',JSON.stringify(b.data.projectData)]);
    await client.query('INSERT INTO simulator_project_versions(project_id,version_number,project_data,created_by) VALUES($1,1,$2,$3)',[rows[0].id,JSON.stringify(b.data.projectData),req.user.id]);
    await client.query('COMMIT'); await audit(req.user.id,'SIMULATOR_PROJECT_CREATED',null,{projectId:rows[0].id}); return reply.code(201).send({project:rows[0]});
  } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
});
app.get('/api/simulator/projects/:id', { preHandler: auth }, async (req,reply) => {
  const {rows}=await pool.query('SELECT * FROM simulator_projects WHERE id=$1',[req.params.id]); const p=rows[0]; if(!p) return reply.code(404).send({error:'PROJECT_NOT_FOUND'}); if(p.owner_id!==req.user.id&&req.user.role!=='FOUNDER') return reply.code(403).send({error:'FORBIDDEN'}); return {project:p};
});
app.put('/api/simulator/projects/:id', { preHandler: auth }, async (req,reply) => {
  const b=z.object({title:z.string().min(1).max(120).optional(),description:z.string().max(1000).optional(),projectData:z.record(z.any())}).safeParse(req.body); if(!b.success) return reply.code(400).send({error:'INVALID_INPUT'});
  const client=await pool.connect();
  try { await client.query('BEGIN'); const found=await client.query('SELECT * FROM simulator_projects WHERE id=$1 FOR UPDATE',[req.params.id]); const old=found.rows[0]; if(!old){await client.query('ROLLBACK');return reply.code(404).send({error:'PROJECT_NOT_FOUND'});} if(old.owner_id!==req.user.id&&req.user.role!=='FOUNDER'){await client.query('ROLLBACK');return reply.code(403).send({error:'FORBIDDEN'});}
    const v=await client.query('SELECT COALESCE(MAX(version_number),0)+1 AS next FROM simulator_project_versions WHERE project_id=$1',[old.id]);
    const {rows}=await client.query(`UPDATE simulator_projects SET title=$2,description=$3,project_data=$4,updated_at=now() WHERE id=$1 RETURNING *`,[old.id,b.data.title??old.title,b.data.description??old.description,JSON.stringify(b.data.projectData)]);
    await client.query('INSERT INTO simulator_project_versions(project_id,version_number,project_data,created_by) VALUES($1,$2,$3,$4)',[old.id,v.rows[0].next,JSON.stringify(b.data.projectData),req.user.id]); await client.query('COMMIT'); await audit(req.user.id,'SIMULATOR_PROJECT_UPDATED',null,{projectId:old.id,version:v.rows[0].next}); return {project:rows[0],version:v.rows[0].next};
  } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
});

app.setErrorHandler((err,req,reply)=>{ req.log.error(err); if(err.code==='23505') return reply.code(409).send({error:'CONFLICT'}); return reply.code(500).send({error:'INTERNAL_SERVER_ERROR'}); });
app.addHook('onClose', async () => pool.end());
const port=Number(process.env.PORT||4000); await app.listen({port,host:process.env.HOST||'0.0.0.0'});
