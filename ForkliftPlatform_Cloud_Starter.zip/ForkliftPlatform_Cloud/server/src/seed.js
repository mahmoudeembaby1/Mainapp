import 'dotenv/config';
import { Pool } from 'pg';
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const components=[
 ['BAT','SOURCE','بطارية DC','DC Battery','battery',[[-40,0],[40,0]],{polarity:['-','+']}],
 ['ACS','SOURCE','مصدر AC أحادي','Single-phase AC Source','ac-source',[[-40,0],[40,0]],{terminals:['L','N']}],
 ['ACS3','SOURCE','مصدر ثلاثي الأوجه','Three-phase AC Source','three-phase-source',[[-40,-20],[-40,0],[-40,20],[40,0]],{terminals:['L1','L2','L3','N']}],
 ['GND','REFERENCE','أرضي','Ground','ground',[[0,-20]],{}],
 ['R','PASSIVE','مقاومة','Resistor','resistor',[[-40,0],[40,0]],{}],
 ['C','PASSIVE','مكثف','Capacitor','capacitor',[[-40,0],[40,0]],{}],
 ['L','PASSIVE','ملف حثي','Inductor','inductor',[[-40,0],[40,0]],{}],
 ['LAMP','LOAD','مصباح','Lamp','lamp',[[-40,0],[40,0]],{}],
 ['LED','SEMICONDUCTOR','LED','LED','led',[[-40,0],[40,0]],{terminals:['A','K']}],
 ['D','SEMICONDUCTOR','دايود','Diode','diode',[[-40,0],[40,0]],{terminals:['A','K']}],
 ['SW','CONTROL','مفتاح عادي','Switch','switch',[[-40,0],[40,0]],{}],
 ['PBS','CONTROL','زر START مفتوح NO','Push Button NO','pushbutton-no',[[-40,0],[40,0]],{}],
 ['PBT','CONTROL','زر STOP مغلق NC','Push Button NC','pushbutton-nc',[[-40,0],[40,0]],{}],
 ['FUSE','PROTECTION','مصهر','Fuse','fuse',[[-40,0],[40,0]],{}],
 ['MCB','PROTECTION','قاطع MCB','Miniature Circuit Breaker','breaker',[[-40,0],[40,0]],{}],
 ['KM','CONTROL','كونتاكتور','Contactor','contactor',[[-30,-60],[0,-60],[30,-60],[-30,60],[0,60],[30,60],[-60,-20],[-60,20],[60,-40],[60,-20],[60,20],[60,40]],{terminals:['1/L1','3/L2','5/L3','2/T1','4/T2','6/T3','A1','A2','13','14','21','22']}],
 ['M','MOTOR','محرك أحادي الوجه','Single-phase Motor','motor-1ph',[[-40,0],[40,0]],{}],
 ['M3','MOTOR','محرك ثلاثي الأوجه','Three-phase Motor','motor-3ph',[[-20,-40],[0,-40],[20,-40]],{terminals:['U','V','W']}],
 ['AM','METER','أميتر','Ammeter','ammeter',[[-40,0],[40,0]],{}],
 ['VM','METER','فولتميتر','Voltmeter','voltmeter',[[-40,0],[40,0]],{}],
 ['TMR','CONTROL','تايمر ON-Delay','ON-delay Timer','timer',[[-48,-20],[-48,20],[48,-20],[48,0],[48,20]],{defaultDelaySeconds:3,terminals:['A1','A2','15','16','18']}],
 ['RLY','CONTROL','ريلاي مساعد','Auxiliary Relay','relay',[[-42,-18],[-42,18],[42,-24],[42,-8],[42,8],[42,24]],{terminals:['A1','A2','13','14','21','22']}]
];
const labelsById={
 BAT:['−','+'],ACS:['L','N'],ACS3:['L1','L2','L3','N'],GND:['PE'],R:['1','2'],C:['1','2'],L:['1','2'],LAMP:['1','2'],LED:['A','K'],D:['A','K'],SW:['1','2'],PBS:['1','2'],PBT:['1','2'],FUSE:['1','2'],MCB:['1','2'],KM:['1/L1','3/L2','5/L3','2/T1','4/T2','6/T3','A1','A2','13','14','21','22'],M:['1','2'],M3:['U','V','W'],AM:['+','−'],VM:['+','−'],TMR:['A1','A2','15','16','18'],RLY:['A1','A2','13','14','21','22']
};
// Planned symbols are stored but kept inactive until their electrical models and UI symbols are implemented in the simulator.
const planned=[
 ['OL','PROTECTION','أوفرلود حراري','Thermal Overload Relay','overload',['L1','L2','L3','T1','T2','T3','95','96','97','98']],
 ['ESTOP','CONTROL','إيقاف طوارئ','Emergency Stop','emergency-stop',['1','2']],
 ['TR','POWER','محول','Transformer','transformer',['P1','P2','S1','S2']],
 ['TB','CONNECTION','بلوك أطراف','Terminal Block','terminal-block',['1','2']],
 ['LS','CONTROL','مفتاح نهاية مشوار','Limit Switch','limit-switch',['COM','NO','NC']],
 ['SEL','CONTROL','مفتاح اختيار','Selector Switch','selector',['COM','NO','NC']]
];
const mk=(name,ac,parts,wires)=>({schemaVersion:1,name,ac,f:50,comps:parts,wires});
const templates=[
 {slug:'dc-lamp-switch-fuse',ar:'دائرة DC: لمبة + مفتاح + فيوز',en:'DC lamp, switch and fuse',cat:'POWER',level:'BEGINNER',desc:'دائرة مستمرة بسيطة من البطارية عبر المصهر والمفتاح إلى المصباح، مع مسار رجوع إلى المصدر.',notes:['ابدأ بجهد تعليمي منخفض.','افصل التغذية قبل تعديل التوصيلات.'],data:mk('DC: Lamp + Switch + Fuse',false,[{id:1,type:'BAT',x:100,y:200,r:0,v:12,on:0},{id:2,type:'FUSE',x:240,y:120,r:0,v:2,on:0},{id:3,type:'SW',x:400,y:120,r:0,on:1},{id:4,type:'LAMP',x:520,y:200,r:0,v:48,v2:12,on:0}],[[0,1,1,0],[1,1,2,0],[2,1,3,0],[3,1,0,0]])},
 {slug:'ac-series-rlc',ar:'دائرة AC: عناصر RLC على التوالي',en:'AC series RLC circuit',cat:'POWER',level:'INTERMEDIATE',desc:'مصدر متردد مع مقاومة وملف ومكثف على التوالي لدراسة الممانعة والتيار.',notes:['القيم الافتراضية للتدريب وليست توصية تصميم.','راقب التردد وتأثيره على الممانعة.'],data:mk('AC series RLC',true,[{id:1,type:'ACS',x:100,y:200,r:0,v:230,v2:50},{id:2,type:'R',x:260,y:100,r:0,v:100},{id:3,type:'L',x:420,y:100,r:0,v:.2},{id:4,type:'C',x:580,y:200,r:0,v:22}],[[0,1,1,0],[1,1,2,0],[2,1,3,0],[3,1,0,0]])},
 {slug:'contactor-self-hold',ar:'دائرة START/STOP وتعشيق ذاتي',en:'START/STOP contactor self-hold',cat:'CONTROL',level:'INTERMEDIATE',desc:'زر إيقاف NC وزر تشغيل NO وملامس مساعد NO للتعشيق الذاتي مع ملف كونتاكتور وحمل توضيحي.',notes:['تأكد من فهم أطراف الملف A1/A2 والملامس 13/14.','المخطط تعليمي ولا يمثل مخطط لوحة صناعية معتمدة.'],data:mk('START STOP + Contactor',false,[{id:1,type:'BAT',x:100,y:300,r:0,v:24},{id:2,type:'PBT',x:240,y:100,r:0},{id:3,type:'PBS',x:400,y:100,r:0},{id:4,type:'KM',x:580,y:240,r:0,v:400,v2:24},{id:5,type:'LAMP',x:760,y:300,r:0,v:48,v2:24}],[[0,1,1,0],[0,1,3,0],[1,1,2,0],[1,1,3,8],[2,1,3,6],[3,9,3,6],[3,7,0,0],[3,3,4,0],[4,1,0,0]])},
 {slug:'three-phase-contactor-motor',ar:'دائرة باور: موتور 3 فاز عبر كونتاكتور',en:'Three-phase motor via contactor',cat:'POWER',level:'INTERMEDIATE',desc:'توصيل ثلاثي الأوجه عبر نقاط الكونتاكتور الرئيسية إلى محرك ثلاثي الأوجه، مع تغذية منفصلة لملف التحكم.',notes:['لا تعتبر هذه الدائرة بديلًا عن القاطع والأوفرلود والحماية المطلوبة.','لا تستخدم جهد الشبكة على نموذج تعليمي أو توصيل فعلي دون مراجعة مختص.'],data:mk('Three-phase motor through contactor',true,[{id:1,type:'ACS3',x:100,y:300,r:0,v:400,v2:50},{id:2,type:'KM',x:360,y:300,r:0,v:400,v2:24},{id:3,type:'M3',x:360,y:520,r:0,v:20},{id:4,type:'ACS',x:100,y:520,r:0,v:24,v2:50},{id:5,type:'SW',x:220,y:600,r:0}],[[0,0,1,0],[0,1,1,1],[0,2,1,2],[1,3,2,0],[1,4,2,1],[1,5,2,2],[3,1,4,0],[4,1,1,6],[1,7,3,0]])},
 {slug:'on-delay-timer-lamp',ar:'دائرة تحكم: تايمر ON-Delay + لمبة',en:'ON-delay timer and lamp',cat:'CONTROL',level:'INTERMEDIATE',desc:'تغذية ملف المؤقت ثم استخدام ملامس 15-18 لتشغيل المصباح بعد انتهاء زمن التأخير.',notes:['قيمة التأخير الافتراضية تعليمية ويمكن تغييرها داخل المحاكي.'],data:mk('ON-delay timer + Lamp',false,[{id:1,type:'BAT',x:100,y:300,r:0,v:24},{id:2,type:'TMR',x:340,y:240,r:0,v:3,v2:24,coilR:400},{id:3,type:'LAMP',x:560,y:240,r:0,v:48,v2:24}],[[0,1,1,0],[1,1,0,0],[0,1,1,2],[1,4,2,0],[2,1,0,0]])},
 {slug:'aux-relay-lamp',ar:'دائرة تحكم: ريلاي مساعد + لمبة',en:'Auxiliary relay and lamp',cat:'CONTROL',level:'BEGINNER',desc:'تغذية ملف الريلاي وملاحظة انتقال الملامس NO 13-14 عند جذب الملف.',notes:['تأكد من مطابقة جهد الملف لمصدر التغذية في أي تنفيذ واقعي.'],data:mk('Auxiliary relay + Lamp',false,[{id:1,type:'BAT',x:100,y:300,r:0,v:24},{id:2,type:'RLY',x:340,y:240,r:0,v:24,v2:24,coilR:400},{id:3,type:'LAMP',x:560,y:240,r:0,v:48,v2:24}],[[0,1,1,0],[1,1,0,0],[0,1,1,2],[1,3,2,0],[2,1,0,0]])}
];
try {
 for(const [id,category,label_ar,label_en,symbol_kind,positions,metadata] of components)
  await pool.query(`INSERT INTO simulator_components(id,category,label_ar,label_en,symbol_kind,terminal_labels,terminal_positions,metadata,active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,true) ON CONFLICT(id) DO UPDATE SET category=EXCLUDED.category,label_ar=EXCLUDED.label_ar,label_en=EXCLUDED.label_en,symbol_kind=EXCLUDED.symbol_kind,terminal_labels=EXCLUDED.terminal_labels,terminal_positions=EXCLUDED.terminal_positions,metadata=EXCLUDED.metadata,active=true,updated_at=now()`,[id,category,label_ar,label_en,symbol_kind,JSON.stringify(labelsById[id]||[]),JSON.stringify(positions),JSON.stringify(metadata)]);
 for(const [id,category,ar,en,kind,terminals] of planned)
  await pool.query(`INSERT INTO simulator_components(id,category,label_ar,label_en,symbol_kind,terminal_labels,terminal_positions,metadata,active) VALUES($1,$2,$3,$4,$5,$6,'[]'::jsonb,$7,false) ON CONFLICT(id) DO UPDATE SET active=false,updated_at=now()`,[id,category,ar,en,kind,JSON.stringify(terminals),JSON.stringify({implementationStatus:'planned'})]);
 const permissionNames=['content_access','screenshot_copy','print','notes_comments','site_settings','word_download','view_all_notes','view_statistics','view_audit_logs','quick_reference_export','manage_users','manage_user_records','manage_roles','manage_simulator_catalog','manage_circuit_templates'];
 const roleDefaults={
  FOUNDER:Object.fromEntries(permissionNames.map(k=>[k,true])),
  ADMIN:{content_access:true,screenshot_copy:true,print:true,notes_comments:true,site_settings:false,word_download:false,view_all_notes:false,view_statistics:false,view_audit_logs:false,quick_reference_export:false,manage_users:true,manage_user_records:true,manage_roles:false,manage_simulator_catalog:true,manage_circuit_templates:true},
  ENGINEER:{content_access:true,screenshot_copy:false,print:false,notes_comments:true,site_settings:false,word_download:false,view_all_notes:false,view_statistics:false,view_audit_logs:false,quick_reference_export:false,manage_users:false,manage_user_records:false,manage_roles:false,manage_simulator_catalog:false,manage_circuit_templates:false},
  SUPERVISOR:{content_access:true,screenshot_copy:false,print:false,notes_comments:true,site_settings:false,word_download:false,view_all_notes:false,view_statistics:false,view_audit_logs:false,quick_reference_export:false,manage_users:false,manage_user_records:false,manage_roles:false,manage_simulator_catalog:false,manage_circuit_templates:false},
  USER:{content_access:true,screenshot_copy:false,print:false,notes_comments:false,site_settings:false,word_download:false,view_all_notes:false,view_statistics:false,view_audit_logs:false,quick_reference_export:false,manage_users:false,manage_user_records:false,manage_roles:false,manage_simulator_catalog:false,manage_circuit_templates:false},
  GUEST:{content_access:false,screenshot_copy:false,print:false,notes_comments:false,site_settings:false,word_download:false,view_all_notes:false,view_statistics:false,view_audit_logs:false,quick_reference_export:false,manage_users:false,manage_user_records:false,manage_roles:false,manage_simulator_catalog:false,manage_circuit_templates:false}
 };
 for(const [role,values] of Object.entries(roleDefaults)) for(const permission of permissionNames)
  await pool.query(`INSERT INTO role_permissions(role,permission,allowed) VALUES($1,$2,$3) ON CONFLICT(role,permission) DO NOTHING`,[role,permission,!!values[permission]]);
 for(const t of templates)
  await pool.query(`INSERT INTO circuit_templates(slug,title_ar,title_en,category,difficulty,description,safety_notes,circuit_data,published) VALUES($1,$2,$3,$4,$5,$6,$7,$8,true) ON CONFLICT(slug) DO UPDATE SET title_ar=EXCLUDED.title_ar,title_en=EXCLUDED.title_en,category=EXCLUDED.category,difficulty=EXCLUDED.difficulty,description=EXCLUDED.description,safety_notes=EXCLUDED.safety_notes,circuit_data=EXCLUDED.circuit_data,published=true,updated_at=now()`,[t.slug,t.ar,t.en,t.cat,t.level,t.desc,JSON.stringify(t.notes),JSON.stringify(t.data)]);
 console.log(`Seeded ${components.length} supported components, ${planned.length} planned/inactive symbols, ${templates.length} ready circuit examples and role permissions.`);
} finally { await pool.end(); }
